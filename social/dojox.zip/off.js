/*
	Copyright (c) 2004-2008, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


if(!dojo._hasResource["dojox.off"]){
dojo._hasResource["dojox.off"]=true;
dojo.provide("dojox.off");
dojo.require("dojox.off._common");
}
